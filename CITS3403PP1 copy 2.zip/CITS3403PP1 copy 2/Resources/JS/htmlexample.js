function changeColour() {
    document.getElementById("colourEg").style.color = "green";
}