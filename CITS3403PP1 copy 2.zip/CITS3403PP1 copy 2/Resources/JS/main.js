function absFunc() {
    document.getElementById('box').setAttribute("class","posAbs")
}

function fixFunc() {
    document.getElementById('box').setAttribute("class","posFix")
}

function relFunc() {
    document.getElementById('box').setAttribute("class","posRel")
}

function uniSelecFunc() {
    document.getElementById('uni').style.color= "#0b6f01";
    document.getElementById('lnk').style.color= "#0b6f01";
}

function classSelecFunc() {
    document.getElementById('classSelec').style.color= "#659fc9";
    document.getElementById('classSelecc').style.color= "#659fc9";
}

function idSelecFunc() {
    document.getElementById('idSelec').style.backgroundColor="#fad3fa";
}

function attSelecFunc() {
    document.getElementById('lnk').style.color="#fa8713";
}

function childSelecFunc() {
    document.getElementById('idSelec').style.backgroundColor="#30bbdd";
    document.getElementById('idSelecc').style.backgroundColor="#30bbdd";
}

function fChildSelecFunc() {
    document.getElementById('fChild').style.backgroundColor="#8add82";
}


function fLetterSelecFunc() {
    document.getElementById('fLetter').setAttribute("class","firstLetter");
    document.getElementById('fLetter2').setAttribute("class","firstLetter");
}

function afterSelecFunc() {
    document.getElementById('afterr').setAttribute("class","aft");

}


